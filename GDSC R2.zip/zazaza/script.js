
document.addEventListener("DOMContentLoaded", function () {
    const posts = document.querySelectorAll(".post");

    posts.forEach((post) => {
        const upvoteButton = post.querySelector(".upvote");
        const replyButton = post.querySelector(".reply");
        const repliesSection = post.querySelector(".replies");
        

        upvoteButton.addEventListener("click", () => {
            
            alert("Upvoted!");
        });

        replyButton.addEventListener("click", () => {

            
           
            const replyTextarea = document.createElement("textarea");
            replyTextarea.placeholder = "Write your reply here...";
            const replySubmitButton = document.createElement("button");
            replySubmitButton.textContent = "Submit Reply";

            replySubmitButton.addEventListener("click", () => {
               
                const replyText = replyTextarea.value;
                const replyElement = document.createElement("div");
                replyElement.textContent = replyText;
                repliesSection.appendChild(replyElement);
                replyTextarea.value = "";
            });

            repliesSection.appendChild(replyTextarea);
            repliesSection.appendChild(replySubmitButton);
        });
    });
});
